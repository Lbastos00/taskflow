# TaskFlow — Trabalho 02 (Angular)

Projeto acadêmico da disciplina Desenvolvimento Web Front-End — FUMEC.

## Integrantes
- Lucas Bastos Lustosa
- Giovana Azevedo

## Requisitos atendidos nesta versão
- Aplicação desenvolvida com Angular e componentes standalone.
- Rotas para Login, Visão geral, Quadro Kanban, Tarefas e Cadastro/Edição.
- Menu de navegação com `routerLink` e `router-outlet`.
- Data-binding com interpolação, property binding, event binding e `[(ngModel)]`.
- Diretivas estruturais `*ngIf` e `*ngFor`, além de `ngClass`.
- Interface `Tarefa` e dados fictícios (mock objects).
- `TarefaService` centraliza listagem, pesquisa, cadastro, edição, exclusão e mudança de status.
- Sem API ou banco de dados, conforme permitido pelo enunciado.

## Como executar
1. Instale Node.js em versão compatível com Angular 20.
2. Extraia o ZIP e abra a pasta `TaskFlow_Angular` no VS Code.
3. No terminal, execute `npm install`.
4. Depois execute `npm start`.
5. Acesse `http://localhost:4200`.

## Demonstração
A tela de login aceita qualquer e-mail válido e senha com pelo menos 4 caracteres. Também é possível clicar em “Acessar demonstração”.

## Observação
Os dados são mantidos em memória durante a execução. Ao atualizar a página, os dados voltam aos mocks iniciais. Não há integração com servidor, API ou banco de dados nesta etapa.

## Git — fluxo sugerido
```bash
git init
git branch -M main
git add .
git commit -m "chore: cria estrutura inicial Angular do TaskFlow"
git branch develop
git checkout -b feature/kanban
git add .
git commit -m "feat: implementa quadro kanban e gerenciamento de tarefas"
git checkout develop
git merge feature/kanban
git checkout main
git merge develop
```
