import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { TarefaService } from '../../services/tarefa.service';
import { Tarefa } from '../../models/tarefa.model';

@Component({
  standalone: true,
  selector: 'app-tarefas',
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page-heading"><div><p class="eyebrow">ACOMPANHAMENTO</p><h1>Tarefas</h1><p class="muted">Pesquise, consulte e gerencie as atividades.</p></div><a class="primary" routerLink="/tarefas/nova">＋ Nova tarefa</a></div>
    <section class="content-card">
      <div class="toolbar"><input class="search" [(ngModel)]="termo" placeholder="Buscar por tarefa ou responsável..."><span class="muted">{{ filtradas.length }} resultado(s)</span></div>
      <div class="table-wrap"><table><thead><tr><th>Tarefa</th><th>Responsável</th><th>Prioridade</th><th>Status</th><th>Prazo</th><th></th></tr></thead>
      <tbody><tr *ngFor="let tarefa of filtradas"><td><strong>{{ tarefa.titulo }}</strong><small>{{ tarefa.descricao }}</small></td><td>{{ tarefa.responsavel }}</td><td><span class="priority" [ngClass]="tarefa.prioridade.toLowerCase()">{{ tarefa.prioridade }}</span></td><td>{{ tarefa.status }}</td><td>{{ tarefa.prazo | date:'dd/MM/yyyy' }}</td><td><a [routerLink]="['/tarefas', tarefa.id, 'editar']">Editar</a></td></tr></tbody></table></div>
      <p class="empty" *ngIf="filtradas.length === 0">Nenhuma tarefa encontrada.</p>
    </section>
  `
})
export class TarefasComponent {
  termo = '';
  constructor(private service: TarefaService) {}
  get filtradas(): Tarefa[] { return this.service.pesquisar(this.termo); }
}