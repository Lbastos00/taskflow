import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { TarefaService } from '../../services/tarefa.service';
import { PrioridadeTarefa, StatusTarefa, Tarefa } from '../../models/tarefa.model';

@Component({
  standalone: true,
  selector: 'app-tarefa-form',
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page-heading"><div><p class="eyebrow">GERENCIAMENTO</p><h1>{{ id ? 'Editar tarefa' : 'Nova tarefa' }}</h1><p class="muted">Preencha os dados da atividade.</p></div></div>
    <section class="content-card form-card">
      <form (ngSubmit)="salvar()">
        <label>Título da tarefa</label><input name="titulo" [(ngModel)]="form.titulo" required placeholder="Ex.: Preparar apresentação">
        <label>Descrição</label><textarea name="descricao" [(ngModel)]="form.descricao" rows="3" placeholder="Descreva a atividade"></textarea>
        <div class="form-grid"><div><label>Responsável</label><select name="responsavel" [(ngModel)]="form.responsavel"><option>Lucas</option><option>Giovana</option></select></div>
        <div><label>Prioridade</label><select name="prioridade" [(ngModel)]="form.prioridade"><option>Baixa</option><option>Média</option><option>Alta</option></select></div>
        <div><label>Status</label><select name="status" [(ngModel)]="form.status"><option>A fazer</option><option>Em andamento</option><option>Concluída</option></select></div>
        <div><label>Prazo</label><input type="date" name="prazo" [(ngModel)]="form.prazo" required></div></div>
        <div class="form-actions"><a class="secondary" routerLink="/tarefas">Cancelar</a><button class="primary" type="submit">Salvar tarefa</button></div>
      </form>
    </section>
  `
})
export class TarefaFormComponent {
  id: number | null = null;
  form: Omit<Tarefa, 'id'> = { titulo: '', descricao: '', responsavel: 'Lucas', prioridade: 'Média', status: 'A fazer', prazo: '2026-11-10' };
  constructor(private service: TarefaService, private route: ActivatedRoute, private router: Router) {
    const idParam = this.route.snapshot.paramMap.get('id');
    if (idParam) {
      this.id = Number(idParam);
      const tarefa = this.service.buscarPorId(this.id);
      if (tarefa) {
        const { id, ...dados } = tarefa;
        this.form = dados;
      }
    }
  }
  salvar(): void {
    if (!this.form.titulo.trim()) return;
    if (this.id !== null) this.service.atualizar(this.id, this.form);
    else this.service.cadastrar(this.form);
    this.router.navigate(['/tarefas']);
  }
}