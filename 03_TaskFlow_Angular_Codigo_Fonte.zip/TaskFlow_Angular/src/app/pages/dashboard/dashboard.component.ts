import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TarefaService } from '../../services/tarefa.service';

@Component({
  standalone: true,
  selector: 'app-dashboard',
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-heading">
      <div><p class="eyebrow">QUARTA-FEIRA, 04 DE NOVEMBRO</p><h1>Visão geral</h1><p class="muted">Acompanhe o andamento das atividades da equipe.</p></div>
      <a class="primary" routerLink="/tarefas/nova">＋ Nova tarefa</a>
    </div>
    <section class="stats">
      <article class="stat-card"><span class="stat-label">Total de tarefas</span><strong>{{ tarefas.length }}</strong><span class="stat-foot">Atividades cadastradas</span></article>
      <article class="stat-card"><span class="stat-label">A fazer</span><strong>{{ contar('A fazer') }}</strong><span class="stat-foot">Aguardando início</span></article>
      <article class="stat-card"><span class="stat-label">Em andamento</span><strong>{{ contar('Em andamento') }}</strong><span class="stat-foot">Em execução</span></article>
      <article class="stat-card"><span class="stat-label">Concluídas</span><strong>{{ contar('Concluída') }}</strong><span class="stat-foot">Finalizadas</span></article>
    </section>
    <section class="content-card">
      <div class="section-head"><div><h2>Atividades recentes</h2><p class="muted">Últimas tarefas do projeto</p></div><a routerLink="/tarefas">Ver todas →</a></div>
      <div class="task-row" *ngFor="let tarefa of tarefas.slice(0,4)">
        <div class="task-icon">✓</div><div class="task-main"><strong>{{ tarefa.titulo }}</strong><small>{{ tarefa.responsavel }} · Prazo {{ tarefa.prazo | date:'dd/MM/yyyy' }}</small></div>
        <span class="priority" [ngClass]="tarefa.prioridade.toLowerCase()">{{ tarefa.prioridade }}</span>
        <span class="status">{{ tarefa.status }}</span>
      </div>
    </section>
  `
})
export class DashboardComponent {
  tarefas = this.service.listar();
  constructor(private service: TarefaService) {}
  contar(status: string): number { return this.tarefas.filter(t => t.status === status).length; }
}