import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-login',
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <section class="login-wrap">
      <div class="login-card">
        <div class="brand large"><span class="brand-mark">T</span> TaskFlow</div>
        <p class="eyebrow">BEM-VINDO DE VOLTA</p>
        <h1>Entre na sua conta</h1>
        <p class="muted">Acesse seu espaço de organização de tarefas.</p>
        <form (ngSubmit)="entrar()">
          <label>E-mail</label>
          <input type="email" name="email" [(ngModel)]="email" required placeholder="seu@email.com">
          <label>Senha</label>
          <input type="password" name="senha" [(ngModel)]="senha" required placeholder="Digite sua senha">
          <p class="error" *ngIf="erro">{{ erro }}</p>
          <button class="primary full" type="submit">Entrar</button>
        </form>
        <p class="demo">Demonstração: use qualquer e-mail e senha com pelo menos 4 caracteres.</p>
        <a routerLink="/dashboard" class="skip">Acessar demonstração</a>
      </div>
    </section>
  `
})
export class LoginComponent {
  email = '';
  senha = '';
  erro = '';
  constructor(private router: Router) {}
  entrar(): void {
    if (!this.email.includes('@') || this.senha.length < 4) {
      this.erro = 'Informe um e-mail válido e uma senha com pelo menos 4 caracteres.';
      return;
    }
    this.router.navigate(['/dashboard']);
  }
}