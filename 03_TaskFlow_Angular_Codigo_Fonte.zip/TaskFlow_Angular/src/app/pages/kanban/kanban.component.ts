import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TarefaService } from '../../services/tarefa.service';
import { StatusTarefa, Tarefa } from '../../models/tarefa.model';

@Component({
  standalone: true,
  selector: 'app-kanban',
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-heading">
      <div><p class="eyebrow">ORGANIZAÇÃO DA EQUIPE</p><h1>Quadro Kanban</h1><p class="muted">Visualize e acompanhe cada etapa do trabalho.</p></div>
      <a class="primary" routerLink="/tarefas/nova">＋ Nova tarefa</a>
    </div>
    <div class="kanban">
      <section class="kanban-column" *ngFor="let coluna of colunas">
        <div class="column-title"><span class="dot" [ngClass]="coluna.css"></span><strong>{{ coluna.nome }}</strong><span class="count">{{ tarefasPorStatus(coluna.nome).length }}</span></div>
        <article class="kanban-card" *ngFor="let tarefa of tarefasPorStatus(coluna.nome)">
          <div class="card-top"><span class="priority" [ngClass]="tarefa.prioridade.toLowerCase()">{{ tarefa.prioridade }}</span><button class="icon-btn" (click)="excluir(tarefa.id)" title="Excluir tarefa">×</button></div>
          <h3>{{ tarefa.titulo }}</h3><p>{{ tarefa.descricao }}</p>
          <div class="card-bottom"><span class="avatar small">{{ tarefa.responsavel.charAt(0) }}</span><span>{{ tarefa.responsavel }}</span><small>Até {{ tarefa.prazo | date:'dd/MM' }}</small></div>
          <div class="card-actions">
            <button *ngIf="tarefa.status !== 'A fazer'" (click)="voltar(tarefa)">←</button>
            <button *ngIf="tarefa.status !== 'Concluída'" (click)="avancar(tarefa)">Avançar →</button>
          </div>
        </article>
        <p class="empty" *ngIf="tarefasPorStatus(coluna.nome).length === 0">Nenhuma tarefa nesta etapa.</p>
      </section>
    </div>
  `
})
export class KanbanComponent {
  colunas = [
    { nome: 'A fazer' as StatusTarefa, css: 'blue' },
    { nome: 'Em andamento' as StatusTarefa, css: 'orange' },
    { nome: 'Concluída' as StatusTarefa, css: 'green' }
  ];
  constructor(private service: TarefaService) {}
  tarefasPorStatus(status: StatusTarefa): Tarefa[] { return this.service.listar().filter(t => t.status === status); }
  avancar(tarefa: Tarefa): void {
    const proximo: StatusTarefa = tarefa.status === 'A fazer' ? 'Em andamento' : 'Concluída';
    this.service.alterarStatus(tarefa.id, proximo);
  }
  voltar(tarefa: Tarefa): void {
    const anterior: StatusTarefa = tarefa.status === 'Concluída' ? 'Em andamento' : 'A fazer';
    this.service.alterarStatus(tarefa.id, anterior);
  }
  excluir(id: number): void {
    if (confirm('Deseja excluir esta tarefa?')) this.service.excluir(id);
  }
}