export type StatusTarefa = 'A fazer' | 'Em andamento' | 'Concluída';
export type PrioridadeTarefa = 'Baixa' | 'Média' | 'Alta';

export interface Tarefa {
  id: number;
  titulo: string;
  descricao: string;
  responsavel: string;
  prioridade: PrioridadeTarefa;
  status: StatusTarefa;
  prazo: string;
}