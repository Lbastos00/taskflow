import { Injectable } from '@angular/core';
import { Tarefa, StatusTarefa } from '../models/tarefa.model';

@Injectable({ providedIn: 'root' })
export class TarefaService {
  private tarefas: Tarefa[] = [
    { id: 1, titulo: 'Definir escopo do projeto', descricao: 'Organizar os requisitos e as entregas da equipe.', responsavel: 'Lucas', prioridade: 'Alta', status: 'Concluída', prazo: '2026-11-06' },
    { id: 2, titulo: 'Criar identidade visual', descricao: 'Definir cores, tipografia e componentes da interface.', responsavel: 'Giovana', prioridade: 'Média', status: 'Em andamento', prazo: '2026-11-08' },
    { id: 3, titulo: 'Implementar quadro Kanban', descricao: 'Exibir tarefas agrupadas por situação.', responsavel: 'Lucas', prioridade: 'Alta', status: 'Em andamento', prazo: '2026-11-10' },
    { id: 4, titulo: 'Revisar relatório', descricao: 'Descrever as telas e as funcionalidades implementadas.', responsavel: 'Giovana', prioridade: 'Média', status: 'A fazer', prazo: '2026-11-12' },
    { id: 5, titulo: 'Validar navegação', descricao: 'Testar as rotas e os links do menu principal.', responsavel: 'Lucas', prioridade: 'Baixa', status: 'A fazer', prazo: '2026-11-13' }
  ];

  listar(): Tarefa[] {
    return [...this.tarefas];
  }

  buscarPorId(id: number): Tarefa | undefined {
    return this.tarefas.find(tarefa => tarefa.id === id);
  }

  pesquisar(termo: string): Tarefa[] {
    const busca = termo.trim().toLowerCase();
    return this.tarefas.filter(tarefa =>
      tarefa.titulo.toLowerCase().includes(busca) ||
      tarefa.responsavel.toLowerCase().includes(busca)
    );
  }

  cadastrar(dados: Omit<Tarefa, 'id'>): void {
    const novoId = Math.max(0, ...this.tarefas.map(tarefa => tarefa.id)) + 1;
    this.tarefas.push({ id: novoId, ...dados });
  }

  atualizar(id: number, dados: Omit<Tarefa, 'id'>): void {
    this.tarefas = this.tarefas.map(tarefa =>
      tarefa.id === id ? { id, ...dados } : tarefa
    );
  }

  alterarStatus(id: number, status: StatusTarefa): void {
    this.tarefas = this.tarefas.map(tarefa =>
      tarefa.id === id ? { ...tarefa, status } : tarefa
    );
  }

  excluir(id: number): void {
    this.tarefas = this.tarefas.filter(tarefa => tarefa.id !== id);
  }
}