import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { TarefaService } from '../../services/tarefa.service';
import { PrioridadeTarefa, StatusTarefa, Tarefa } from '../../models/tarefa.model';
@Component({standalone:true,selector:'app-tarefa-form',imports:[CommonModule,ReactiveFormsModule,RouterLink],template:`
  <div class="page-heading"><div><p class="eyebrow">GERENCIAMENTO</p><h1>{{id !== null ? 'Editar tarefa' : 'Nova tarefa'}}</h1><p class="muted">Preencha os dados da atividade.</p></div></div>
  <section class="content-card form-card"><p class="error" *ngIf="erro">{{erro}}</p><p class="muted" *ngIf="carregando">Carregando tarefa...</p>
    <form [formGroup]="form" (ngSubmit)="salvar()" novalidate>
      <label for="titulo">Título da tarefa *</label><input id="titulo" formControlName="titulo" maxlength="100" placeholder="Ex.: Preparar apresentação" [attr.aria-invalid]="invalido('titulo')">
      <p class="error" *ngIf="invalido('titulo')">Informe um título entre 3 e 100 caracteres.</p>
      <label for="descricao">Descrição *</label><textarea id="descricao" formControlName="descricao" rows="3" maxlength="500" placeholder="Descreva a atividade"></textarea><p class="error" *ngIf="invalido('descricao')">Informe uma descrição de pelo menos 5 caracteres.</p>
      <div class="form-grid"><div><label for="responsavel">Responsável *</label><select id="responsavel" formControlName="responsavel"><option value="Lucas">Lucas</option><option value="Giovana">Giovana</option></select></div>
      <div><label for="prioridade">Prioridade *</label><select id="prioridade" formControlName="prioridade"><option value="Baixa">Baixa</option><option value="Média">Média</option><option value="Alta">Alta</option></select></div>
      <div><label for="status">Status *</label><select id="status" formControlName="status"><option value="A fazer">A fazer</option><option value="Em andamento">Em andamento</option><option value="Concluída">Concluída</option></select></div>
      <div><label for="prazo">Prazo *</label><input id="prazo" type="date" formControlName="prazo"><p class="error" *ngIf="invalido('prazo')">Informe uma data válida.</p></div></div>
      <div class="form-actions"><a class="secondary" routerLink="/tarefas">Cancelar</a><button class="primary" type="submit" [disabled]="salvando || carregando">{{salvando ? 'Salvando...' : 'Salvar tarefa'}}</button></div>
    </form>
  </section>`})
export class TarefaFormComponent implements OnInit {
  private readonly fb=inject(FormBuilder);private readonly service=inject(TarefaService);private readonly route=inject(ActivatedRoute);private readonly router=inject(Router);
  id:string|null=null;erro='';salvando=false;carregando=false;tentou=false;
  form=this.fb.nonNullable.group({titulo:['',[Validators.required,Validators.minLength(3),Validators.maxLength(100)]],descricao:['',[Validators.required,Validators.minLength(5)]],responsavel:['Lucas',Validators.required],prioridade:['Média',Validators.required],status:['A fazer',Validators.required],prazo:['',Validators.required]});
  ngOnInit():void{const param=this.route.snapshot.paramMap.get('id');if(param){this.id=param;if(!/^\d+$/.test(this.id)){this.erro='Identificador inválido.';return;}this.carregando=true;this.service.buscarPorId(this.id).subscribe({next:t=>{this.form.patchValue(t);this.carregando=false;},error:()=>{this.erro='Tarefa não encontrada ou API indisponível.';this.carregando=false;}});}}
  invalido(nome:string):boolean{const c=this.form.get(nome);return !!c?.invalid&&(!!c.touched||this.tentou);}
  salvar():void{this.tentou=true;this.form.markAllAsTouched();if(this.form.invalid||this.salvando||this.carregando)return;
    this.salvando=true;this.erro='';const raw=this.form.getRawValue();const dados:Omit<Tarefa,'id'>={titulo:raw.titulo.trim(),descricao:raw.descricao.trim(),responsavel:raw.responsavel,prioridade:raw.prioridade as PrioridadeTarefa,status:raw.status as StatusTarefa,prazo:raw.prazo};
    const pedido=this.id!==null?this.service.atualizar(this.id,dados):this.service.cadastrar(dados);
    pedido.subscribe({next:()=>{this.salvando=false;void this.router.navigate(['/tarefas']);},error:()=>{this.erro='Não foi possível salvar. Verifique se o JSON-Server está ativo.';this.salvando=false;}});
  }
}
