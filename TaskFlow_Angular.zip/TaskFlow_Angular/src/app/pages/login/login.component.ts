import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
@Component({standalone:true,selector:'app-login',imports:[CommonModule,ReactiveFormsModule,RouterLink],template:`
  <section class="login-wrap"><div class="login-card"><div class="brand large"><span class="brand-mark">T</span> TaskFlow</div><p class="eyebrow">BEM-VINDO DE VOLTA</p><h1>Entre na sua conta</h1><p class="muted">Acesse seu espaço de organização de tarefas.</p>
    <form [formGroup]="form" (ngSubmit)="entrar()" novalidate>
      <label for="email">E-mail</label><input id="email" type="email" formControlName="email" placeholder="seu@email.com"><p class="error" *ngIf="invalido('email')">Informe um e-mail válido.</p>
      <label for="senha">Senha</label><input id="senha" type="password" formControlName="senha" placeholder="Digite sua senha"><p class="error" *ngIf="invalido('senha')">A senha precisa ter pelo menos 4 caracteres.</p>
      <button class="primary full" type="submit">Entrar</button>
    </form><p class="demo">Demonstração: use qualquer e-mail válido e senha com pelo menos 4 caracteres. Não há autenticação real.</p><a routerLink="/dashboard" class="skip">Acessar demonstração</a>
  </div></section>`})
export class LoginComponent {
  private readonly fb=inject(FormBuilder);private readonly router=inject(Router);tentou=false;
  form=this.fb.nonNullable.group({email:['',[Validators.required,Validators.email]],senha:['',[Validators.required,Validators.minLength(4)]]});
  invalido(nome:string):boolean{const c=this.form.get(nome);return !!c?.invalid&&(!!c.touched||this.tentou);}
  entrar():void{this.tentou=true;this.form.markAllAsTouched();if(this.form.valid)void this.router.navigate(['/dashboard']);}
}
