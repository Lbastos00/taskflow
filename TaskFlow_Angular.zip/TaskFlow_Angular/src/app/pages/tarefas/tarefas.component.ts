import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { debounceTime, distinctUntilChanged, startWith, switchMap, catchError, of } from 'rxjs';
import { TarefaService } from '../../services/tarefa.service';
import { Tarefa } from '../../models/tarefa.model';
@Component({standalone:true,selector:'app-tarefas',imports:[CommonModule,ReactiveFormsModule,RouterLink],template:`
  <div class="page-heading"><div><p class="eyebrow">ACOMPANHAMENTO</p><h1>Tarefas</h1><p class="muted">Pesquise, consulte e gerencie as atividades.</p></div><a class="primary" routerLink="/tarefas/nova">＋ Nova tarefa</a></div>
  <section class="content-card"><div class="toolbar"><input class="search" [formControl]="busca" placeholder="Buscar por tarefa ou responsável..."><span class="muted">{{filtradas.length}} resultado(s)</span></div>
    <p class="error" *ngIf="erro">{{erro}}</p>
    <div class="table-wrap"><table><thead><tr><th>Tarefa</th><th>Responsável</th><th>Prioridade</th><th>Status</th><th>Prazo</th><th>Ações</th></tr></thead><tbody>
      <tr *ngFor="let tarefa of filtradas"><td><strong>{{tarefa.titulo}}</strong><small>{{tarefa.descricao}}</small></td><td>{{tarefa.responsavel}}</td><td><span class="priority" [ngClass]="tarefa.prioridade.toLowerCase()">{{tarefa.prioridade}}</span></td><td>{{tarefa.status}}</td><td>{{tarefa.prazo | date:'dd/MM/yyyy'}}</td><td><a [routerLink]="['/tarefas',tarefa.id,'editar']">Editar</a> <button type="button" [disabled]="ocupado" (click)="excluir(tarefa.id)">Excluir</button></td></tr>
    </tbody></table></div><p class="empty" *ngIf="filtradas.length===0">Nenhuma tarefa encontrada.</p>
  </section>`})
export class TarefasComponent implements OnInit {
  private readonly service=inject(TarefaService);
  busca=new FormControl('',{nonNullable:true});filtradas:Tarefa[]=[];erro='';ocupado=false;
  ngOnInit():void{this.busca.valueChanges.pipe(startWith(this.busca.value),debounceTime(200),distinctUntilChanged(),switchMap(termo=>this.service.pesquisar(termo).pipe(catchError(()=>{this.erro='Não foi possível consultar a API na porta 3000.';return of([] as Tarefa[]);})))) .subscribe(tarefas=>{this.filtradas=tarefas;});}
  excluir(id:string):void{if(!confirm('Deseja excluir esta tarefa?'))return;this.ocupado=true;this.service.excluir(id).subscribe({next:()=>{this.filtradas=this.filtradas.filter(t=>t.id!==id);this.ocupado=false;},error:()=>{this.erro='Erro ao excluir tarefa.';this.ocupado=false;}});}
}
