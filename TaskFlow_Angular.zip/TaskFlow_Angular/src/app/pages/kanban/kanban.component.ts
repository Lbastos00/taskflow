import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TarefaService } from '../../services/tarefa.service';
import { StatusTarefa, Tarefa } from '../../models/tarefa.model';
@Component({standalone:true,selector:'app-kanban',imports:[CommonModule,RouterLink],template:`
  <div class="page-heading"><div><p class="eyebrow">ORGANIZAÇÃO DA EQUIPE</p><h1>Quadro Kanban</h1><p class="muted">Visualize e acompanhe cada etapa do trabalho.</p></div><a class="primary" routerLink="/tarefas/nova">＋ Nova tarefa</a></div>
  <p class="error" *ngIf="erro">{{erro}} <button type="button" (click)="carregar()">Tentar novamente</button></p>
  <p class="muted" *ngIf="carregando">Carregando...</p>
  <div class="kanban"><section class="kanban-column" *ngFor="let coluna of colunas">
    <div class="column-title"><span class="dot" [ngClass]="coluna.css"></span><strong>{{coluna.nome}}</strong><span class="count">{{tarefasPorStatus(coluna.nome).length}}</span></div>
    <article class="kanban-card" *ngFor="let tarefa of tarefasPorStatus(coluna.nome)">
      <div class="card-top"><span class="priority" [ngClass]="tarefa.prioridade.toLowerCase()">{{tarefa.prioridade}}</span><button class="icon-btn" type="button" [disabled]="ocupado" (click)="excluir(tarefa.id)" title="Excluir tarefa">×</button></div>
      <h3>{{tarefa.titulo}}</h3><p>{{tarefa.descricao}}</p>
      <div class="card-bottom"><span class="avatar small">{{tarefa.responsavel.charAt(0)}}</span><span>{{tarefa.responsavel}}</span><small>Até {{tarefa.prazo | date:'dd/MM'}}</small></div>
      <div class="card-actions"><button type="button" [disabled]="ocupado" *ngIf="tarefa.status !== 'A fazer'" (click)="voltar(tarefa)">← Voltar</button><button type="button" [disabled]="ocupado" *ngIf="tarefa.status !== 'Concluída'" (click)="avancar(tarefa)">Avançar →</button><a [routerLink]="['/tarefas',tarefa.id,'editar']">Editar</a></div>
    </article><p class="empty" *ngIf="tarefasPorStatus(coluna.nome).length === 0">Nenhuma tarefa nesta etapa.</p>
  </section></div>`})
export class KanbanComponent implements OnInit {
  private readonly service=inject(TarefaService);
  tarefas:Tarefa[]=[]; erro=''; carregando=false; ocupado=false;
  colunas=[{nome:'A fazer' as StatusTarefa,css:'blue'},{nome:'Em andamento' as StatusTarefa,css:'orange'},{nome:'Concluída' as StatusTarefa,css:'green'}];
  ngOnInit():void{this.carregar();}
  carregar():void{this.carregando=true;this.erro='';this.service.listar().subscribe({next:ts=>{this.tarefas=ts;this.carregando=false;},error:()=>{this.erro='Falha ao carregar tarefas. Verifique a API na porta 3000.';this.carregando=false;}});}
  tarefasPorStatus(status:StatusTarefa):Tarefa[]{return this.tarefas.filter(t=>t.status===status);}
  avancar(t:Tarefa):void{this.mudar(t,t.status==='A fazer'?'Em andamento':'Concluída');}
  voltar(t:Tarefa):void{this.mudar(t,t.status==='Concluída'?'Em andamento':'A fazer');}
  mudar(t:Tarefa,status:StatusTarefa):void{this.ocupado=true;this.erro='';this.service.alterarStatus(t.id,status).subscribe({next:atualizada=>{this.tarefas=this.tarefas.map(item=>item.id===t.id?atualizada:item);this.ocupado=false;},error:()=>{this.erro='Não foi possível atualizar o status.';this.ocupado=false;}});}
  excluir(id:string):void{if(!confirm('Deseja excluir esta tarefa?'))return;this.ocupado=true;this.erro='';this.service.excluir(id).subscribe({next:()=>{this.tarefas=this.tarefas.filter(t=>t.id!==id);this.ocupado=false;},error:()=>{this.erro='Não foi possível excluir a tarefa.';this.ocupado=false;}});}
}
