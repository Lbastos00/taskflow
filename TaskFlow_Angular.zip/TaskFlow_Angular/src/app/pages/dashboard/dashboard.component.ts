import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { TarefaService } from '../../services/tarefa.service';
import { Tarefa, StatusTarefa } from '../../models/tarefa.model';
@Component({
  standalone: true, selector: 'app-dashboard', imports: [CommonModule, RouterLink],
  template: `
    <div class="page-heading"><div><p class="eyebrow">ACOMPANHAMENTO DO PROJETO</p><h1>Visão geral</h1><p class="muted">Acompanhe o andamento das atividades da equipe.</p></div><a class="primary" routerLink="/tarefas/nova">＋ Nova tarefa</a></div>
    <p class="error" *ngIf="erro">{{ erro }} <button type="button" (click)="carregar()">Tentar novamente</button></p>
    <section class="stats">
      <article class="stat-card"><span class="stat-label">Total de tarefas</span><strong>{{ tarefas.length }}</strong><span class="stat-foot">Atividades cadastradas</span></article>
      <article class="stat-card"><span class="stat-label">A fazer</span><strong>{{ contar('A fazer') }}</strong><span class="stat-foot">Aguardando início</span></article>
      <article class="stat-card"><span class="stat-label">Em andamento</span><strong>{{ contar('Em andamento') }}</strong><span class="stat-foot">Em execução</span></article>
      <article class="stat-card"><span class="stat-label">Concluídas</span><strong>{{ contar('Concluída') }}</strong><span class="stat-foot">Finalizadas</span></article>
    </section>
    <section class="content-card"><div class="section-head"><div><h2>Atividades recentes</h2><p class="muted">Últimas tarefas do projeto</p></div><a routerLink="/tarefas">Ver todas →</a></div>
      <p class="muted" *ngIf="carregando">Carregando tarefas...</p>
      <div class="task-row" *ngFor="let tarefa of tarefas.slice(0,4)"><div class="task-icon">✓</div><div class="task-main"><strong>{{ tarefa.titulo }}</strong><small>{{ tarefa.responsavel }} · Prazo {{ tarefa.prazo | date:'dd/MM/yyyy' }}</small></div><span class="priority" [ngClass]="tarefa.prioridade.toLowerCase()">{{ tarefa.prioridade }}</span><span class="status">{{ tarefa.status }}</span></div>
    </section>`
})
export class DashboardComponent implements OnInit {
  private readonly service = inject(TarefaService);
  tarefas: Tarefa[] = []; erro = ''; carregando = false;
  ngOnInit(): void { this.carregar(); }
  carregar(): void { this.carregando = true; this.erro = ''; this.service.listar().subscribe({
    next: tarefas => { this.tarefas = tarefas; this.carregando = false; },
    error: () => { this.erro = 'Não foi possível acessar a API. Inicie o JSON-Server na porta 3000.'; this.carregando = false; }
  }); }
  contar(status: StatusTarefa): number { return this.tarefas.filter(t => t.status === status).length; }
}
