import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { KanbanComponent } from './pages/kanban/kanban.component';
import { TarefasComponent } from './pages/tarefas/tarefas.component';
import { TarefaFormComponent } from './pages/tarefa-form/tarefa-form.component';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'kanban', component: KanbanComponent },
  { path: 'tarefas', component: TarefasComponent },
  { path: 'tarefas/nova', component: TarefaFormComponent },
  { path: 'tarefas/:id/editar', component: TarefaFormComponent },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'dashboard' }
];