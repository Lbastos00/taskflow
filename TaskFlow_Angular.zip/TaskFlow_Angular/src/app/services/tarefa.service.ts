import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Tarefa, StatusTarefa } from '../models/tarefa.model';

@Injectable({ providedIn: 'root' })
export class TarefaService {
  private readonly http = inject(HttpClient);
  private readonly url = 'http://localhost:3000/tarefas';

  listar(): Observable<Tarefa[]> { return this.http.get<Tarefa[]>(this.url); }
  buscarPorId(id: string): Observable<Tarefa> { return this.http.get<Tarefa>(`${this.url}/${id}`); }
  pesquisar(termo: string): Observable<Tarefa[]> {
    const busca = termo.trim();
    return busca ? this.http.get<Tarefa[]>(this.url, { params: { q: busca } }) : this.listar();
  }
  cadastrar(dados: Omit<Tarefa, 'id'>): Observable<Tarefa> { return this.http.post<Tarefa>(this.url, dados); }
  atualizar(id: string, dados: Omit<Tarefa, 'id'>): Observable<Tarefa> { return this.http.put<Tarefa>(`${this.url}/${id}`, dados); }
  alterarStatus(id: string, status: StatusTarefa): Observable<Tarefa> {
    return this.http.patch<Tarefa>(`${this.url}/${id}`, { status });
  }
  excluir(id: string): Observable<void> { return this.http.delete<void>(`${this.url}/${id}`); }
}
