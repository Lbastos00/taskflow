import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterLink, RouterLinkActive, RouterOutlet],
  template: `
    <header class="topbar">
      <a class="brand" routerLink="/dashboard"><span class="brand-mark">T</span> TaskFlow</a>
      <nav>
        <a routerLink="/dashboard" routerLinkActive="active">Visão geral</a>
        <a routerLink="/kanban" routerLinkActive="active">Quadro Kanban</a>
        <a routerLink="/tarefas" routerLinkActive="active">Tarefas</a>
      </nav>
      <a class="profile" routerLink="/login"><span class="avatar">L</span><span>Lucas</span></a>
    </header>
    <main class="page-shell"><router-outlet /></main>
  `
})
export class AppComponent {}